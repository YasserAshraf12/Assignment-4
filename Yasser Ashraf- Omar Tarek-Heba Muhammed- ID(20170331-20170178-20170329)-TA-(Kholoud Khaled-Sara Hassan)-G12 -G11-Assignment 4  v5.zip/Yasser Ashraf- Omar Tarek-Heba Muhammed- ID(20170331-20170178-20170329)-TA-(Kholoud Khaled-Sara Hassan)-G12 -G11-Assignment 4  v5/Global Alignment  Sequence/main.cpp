#include <iostream>
#include<cstring>
#include <string>
#include<algorithm>
#include<vector>
#include<cstdio>
using namespace std;
int Max(int a, int b,int c)//to find the max score...
{
    if(a>b&&a>c)
    {
        return a;
    }
    if(b>a&&b>c)
    {
        return b;
    }
    if(c>b&&c>a)
    {
        return c;
    }
}
void globalAlignment(Sequence* s1, Sequence& s2)
{
	int DNA::Max(int a, int b,int c)//to find the max score...
{
    if(a>b&&a>c)
    {
        return a;
    }
    if(b>a&&b>c)
    {
        return b;
    }
    if(c>b&&c>a)
    {
        return c;
    }
}
///--------------------------------------------------------------
void globalAlignment(DNA*s1, DNA&s2)
{
    int m = s1->length;
    int n = s2.length;
    int data[m][n];
    //assumed scores....
    int const Gap=-1;
    int const Match=1;
    int const Mismatch=-1;
    int score;
    //filling scoring matrix....
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            score=0;
            if(i==0&&j==0)
            {
                data[i][j]=0;
            }
            else if(i==0&&j>0)
            {
                data[i][j]=-j;
            }
            else if(i>0&&j==0)
            {
                data[i][j]=-i;
            }
            else
            {
                if(s1->sequence[i] == s2.sequence[j])
                {
                    score = Max((data[i-1][j]+Gap),(data[i][j-1]+Gap),(data[i-1][j-1]+Match));
                    data[i][j] = score;
                }
                else
                {
                    score = Max((data[i-1][j]+Gap),(data[i][j-1]+Gap),(data[i-1][j-1]+Mismatch));
                    data[i][j]=score;
                }
            }
        }
    }
    vector <char> GlobalAlin;
    vector <char> GlobalAlin2;
    int i=m;
    int j=n;
    while(i>0&&j>0)
    {
        if(s1->sequence[i] == s2.sequence[j])
        {
            GlobalAlin.push_back(s1->sequence[i]);
            GlobalAlin2.push_back(s2.sequence[j]);
            i--;
            j--;
        }
        else{
            if(data[i-1][j-1]>data[i][j-1]&&data[i-1][j-1]>data[i-1][j])
            {
                GlobalAlin.push_back(s1->sequence[i]);
                GlobalAlin2.push_back(s2.sequence[j]);
                i--;
                j--;
            }
            else if(data[i-1][j]>data[i][j-1])
            {
                GlobalAlin.push_back(s1->sequence[i]);
                GlobalAlin2.push_back('-');
                i--;
            }
            else
            {
                GlobalAlin.push_back('-');
                GlobalAlin2.push_back(s2.sequence[j]);
                j--;
            }
        }
    }
    reverse(GlobalAlin.begin(),GlobalAlin.end());
    reverse(GlobalAlin2.begin(),GlobalAlin2.end());
    for(int i=0;i<m;i++)
    {
        cout<<GlobalAlin[i]<<"	";
    }
    cout<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<GlobalAlin2[i]<<"	";
    }
}
int main()
{
	return 0;
}
