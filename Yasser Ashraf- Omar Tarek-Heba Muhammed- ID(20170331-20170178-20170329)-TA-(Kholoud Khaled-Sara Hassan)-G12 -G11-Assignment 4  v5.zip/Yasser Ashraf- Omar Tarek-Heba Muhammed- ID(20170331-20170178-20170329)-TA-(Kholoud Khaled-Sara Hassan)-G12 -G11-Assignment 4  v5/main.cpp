/*
Program:     Biology Strands Modification.
Authors:     Yasser Ashraf Salah & Heba Muhammed Ali & Omar Tarek Abd El Aziz.
Date:        13 - 12 - 2018.
Version:     V5.0.
V1.0. Simple Coding without Get dNA Strand And Conversion To Protein And Without Exception Handling
V2.0. Operators And Exception Handling be Covered.
V3.0. Alignment and Comments and Readable Coding Style.
V4.0. Load And Save Operation and Menu Formatting To Supply User Good Use.
V5.0. Current Version The Final Version The Last Modification .
Global Program
Contains 5 Classes: Parent is Sequence and has 3 Child Classes (DNA & RNA and Protein)
Fifth Class is CodonsTable which exists inside the conversion of Protein(Convert from RNA to Protein or Convert from Protein to RNA).
*/
#include<iostream>
#include<fstream>
#include"Sequence.h"
#include"DNA.h"
#include"Protein.h"
#include"RNA.h"
#include<cstring>
using namespace std;
//---------------------------------------------------------------------------
int main()
{
    streambuf* stream_buffer_cin ; ///Buffer to determine use normal cin or cin inside file.
    streambuf* stream_buffer_file; ///Buffer for the file for cin
     streambuf* stream_buffer_cout ; /// Buffer to determine use normal cout or cout file file
    streambuf* stream_buffer_file2;///Buffer for file for cout
    fstream file; /// file to read from it.
    fstream file2; /// file to load to it.
    bool save = false; /// boolen for save Property
    bool load= false; ///boolen for load Property
    int ch; /// choice for Save || Load || Both Operation || normal
    cout<<" Please Choose Your Operation:   "<<endl;
    cout<<" 1-Save To File \n 2-Load From File \n 3-Both Save and Load \n 4- none "<<endl;
    cin >>ch; /// cin value
    if(ch == 1) /// choose save
    {
        save = true;
    }
    else if(ch == 2) /// choose load
        load = true;
    else if(ch == 3) /// choose Both
    {
        load = true;
        save = true;
    }
    if(save){ /// Select and Create File to use it in save operation
      file2.open("output.txt", ios::out);
        stream_buffer_cout = cout.rdbuf();
        stream_buffer_file2 = file2.rdbuf();
    }
    if(load){ ///Select File to Read from it
        file.open("input.txt", ios::in);
        stream_buffer_cin = cin.rdbuf();
        stream_buffer_file = file.rdbuf();
    }
    bool cont  = true; /// Main Boolen to Controll Main Menu
    while(cont){
        cout<<" 1-DNA Sequence \n 2-RNA Sequence \n 3-Protein Sequence \n 0-Exit"<<endl;
        cout<<endl;
        int x; /// for Sequences Option
        int y; /// for Options Property
        cout<<" Please Enter Your Choice:    ";
        cin>>x;
        if( x == 1){///choose Dna
            cout<<"--------------------You Choose DNA Sequence--------------------"<<endl;
            cout<<endl;
            cout<<" Please Choose Operation:"<<endl;
            cout<<" 1- Get Complement strand \n 2- Convert To RNA \n 3- Sum two DNA Strand \n 4- Check Equality \n 5- Print"<<endl;
            cin>>y;
            cout<<endl;
            DNA d1;
            try{ /// Check Exceptin
                if(load)
                {
                    cin.rdbuf(stream_buffer_file);  // in oreder to load from file
                    cin>>d1;
                    cin.rdbuf(stream_buffer_cin); // in order to load from cin
                }
                else
                    cin>>d1;
            }
            catch(exception &m){ /// Catch Exception
                cout<<endl;
                cout<<m.what()<<endl;
                return 0;
            }
            if(y ==1){
                int c,v;
                cout<<" Please Enter The Start Index for Complement Strand:  ";
                cin>>c;
                cout<<" Please Enter The End Index for Complement Strand:  ";
                cin>>v;
                cout<<endl;
                d1.BuildComplementaryStrand(c,v); /// Complement Strand
                if(save){
                    cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                    cout<<"The Complementary Strand is:     "<<endl;;
                    cout<<d1<<endl;
                    cout.rdbuf(stream_buffer_cout); // in order to load from cin
                }
                else{
                    cout<<"The Complementary Strand is:     "<<endl;;
                    cout<<d1<<endl;
                }
            }
            else if(y==2)
            {
                RNA r1;
                r1 = d1.ConvertToRNA(); /// Convert to RNa
                if(save){
                cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                cout<<r1<<endl;
                cout.rdbuf(stream_buffer_cout); // in order to load from cin
                }
                else{
                    cout<<r1<<endl;
                }
            }
            else if(y==3)
            {
                DNA d2;
                try{
                    if(load)
                    {
                        cin.rdbuf(stream_buffer_file);  // in oreder to load from file
                        cin>>d2;
                        cin.rdbuf(stream_buffer_cin); // in order to load from cin
                    }
                    else
                        cin>>d2;
                }
                catch(exception &m){
                    cout<<endl;
                    cout<<m.what()<<endl;
                    return 0;
                }
                cout<<endl;
                DNA d3;
                d3 = d1 + d2; /// Sum Two DNA Strand to Each other
                if(save){
                cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                cout<<d3<<endl;
                cout.rdbuf(stream_buffer_cout); // in order to load from cin
                }
                else{
                     cout<<d3<<endl;
                }
            }
            else if(y==4)
            {
                DNA d4;
                try{
                    if(load)
                    {
                        cin.rdbuf(stream_buffer_file);  // in oreder to load from file
                        cin>>d4;
                        cin.rdbuf(stream_buffer_cin); // in order to load from cin
                    }
                    else
                        cin>>d4;
                }
                catch(exception &m){
                    cout<<endl;
                    cout<<m.what()<<endl;
                    return 0;
                }
                cout<<endl;
                if(d1 == d4){ /// Check if Equal
                    if(save){
                    cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                    cout<<endl;
                    cout<<" Idenitcal Two DNA"<<endl;
                    cout.rdbuf(stream_buffer_cout); // in order to load from cin
                    }
                    else{ /// Check if not Equal
                        cout<<endl;
                        cout<<" Idenitcal Two DNA"<<endl;
                    }
                }
                else{
                    if(save){
                    cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                    cout<<endl;
                    cout<<" Not Equal"<<endl;
                    cout.rdbuf(stream_buffer_cout); // in order to load from cin
                    }
                    else{
                        cout<<endl;
                        cout<<" Not Equal"<<endl;
                    }
                }
            }
            else if(y==5){
                if(save){
                cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                cout<<endl;
                d1.Print(); /// Print Data
                cout.rdbuf(stream_buffer_cout); // in order to load from cin
                }
                else{
                    cout<<endl;
                    d1.Print();
                }
            }
        }
        ///------------------------------------------------------------------------------------------------------------------
        else if(x == 2){
            cout<<"--------------------You Choose RNA Sequence--------------------"<<endl;
            cout<<" Choose The Operation:    ";
            cout<<endl;
            cout<<" 1- Convert To DNA \n 2- Convert To Protein \n 3- Sum two RNA Strand \n 4- Check Equality \n 5- Print"<<endl;
            cin>>y;
            cout<<endl;
            RNA d1;
            try{
                if(load)
                {
                    cin.rdbuf(stream_buffer_file);  // in oreder to load from file
                    cin>>d1;
                    cin.rdbuf(stream_buffer_cin); // in order to load from cin
                }
                else
                    cin>>d1;
            }
            catch(exception &n){
                cout<<endl;
                cout<<n.what()<<endl;
                return 0;
            }
            if(y ==1)
            {
                DNA r1;
                r1 = d1.ConvertToDNA();
                if(save){
                cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                cout << r1 << endl;
                cout.rdbuf(stream_buffer_cout); // in order to load from cin
                }
                else{
                    cout << r1 << endl;
                }
            }
            else if(y==2)
            {
                Protein p1;
                CodonsTable Table;
                p1 = d1.ConvertToProtein(Table);
                if(save){
                cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                cout << p1 << endl;
                cout.rdbuf(stream_buffer_cout); // in order to load from cin
                }
                else{
                    cout << p1 << endl;
                }
            }
            else if(y==3)
            {
                RNA d2;
                try{
                    if(load)
                    {
                        cin.rdbuf(stream_buffer_file);  // in oreder to load from file
                        cin>>d2;
                        cin.rdbuf(stream_buffer_cin); // in order to load from cin
                    }
                    else
                        cin>>d2;
                }
                catch(exception &n){
                    cout<<endl;
                    cout<<n.what()<<endl;
                    return 0;
                }
                cout<<endl;
                RNA d3;
                d3 = d1 + d2;
                if(save)
                {
                cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                cout<<d3<<endl;
                cout.rdbuf(stream_buffer_cout); // in order to load from cin
                }
                else{
                    cout<<d3<<endl;
                }
            }
            else if(y==4)
            {
                RNA d4;
                try
                {
                    if(load)
                    {
                        cin.rdbuf(stream_buffer_file);  // in oreder to load from file
                        cin>>d1;
                        cin.rdbuf(stream_buffer_cin); // in order to load from cin
                    }
                    else
                        cin>>d1;
                    }
                catch(exception &n)
                {
                    cout<<endl;
                    cout<< n.what()<<endl;
                    return 0;
                }
                cout<<endl;
                if(d1 == d4){
                    if(save){
                    cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                    cout<<endl;
                    cout<<" Indetical Two RNA"<<endl;
                    cout.rdbuf(stream_buffer_cout); // in order to load from cin
                    }
                    else{
                        cout<<endl;
                        cout<<" Indetical Two RNA"<<endl;
                    }
                }
                else{
                    if(save){
                    cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                    cout<<endl;
                    cout<<" Not Equal!"<<endl;
                    cout.rdbuf(stream_buffer_cout); // in order to load from cin
                    }
                    else{
                        cout<<endl;
                        cout<<" Not Equal!"<<endl;
                    }
                }
            }
            else if(y==5){
                if(save){
                cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                cout<<endl;
                d1.Print();
                cout.rdbuf(stream_buffer_cout); // in order to load from cin
                }
                else{
                    cout<<endl;
                    d1.Print();
                }
            }
        }
        else if(x == 3){
            cout<<"--------------------You Choose Protein Sequence--------------------"<<endl;
            cout<<" Choose The Operation:    ";
            cout<<endl;
            cout<<" 1- Get DNA Strand \n 2- Sum two RNA Strand \n 3- Check Equality \n 4- Print"<<endl;
            cin>>y;
            cout<<endl;
            Protein d1;
            try
            {
                if(load)
                {
                    cin.rdbuf(stream_buffer_file);  // in oreder to load from file
                    cin>>d1;
                    cin.rdbuf(stream_buffer_cin); // in order to load from cin
                }
                else
                    cin>>d1;
            }
            catch(exception &l){
                cout<<endl;
                cout<<l.what()<<endl;
                return 0;
            }
            if(y == 1)
            {
                cout<<" Enter The Big DNA :  "<<endl;
                DNA r2;
                try
                {
                    if(load)
                    {
                        cin.rdbuf(stream_buffer_file);  // in oreder to load from file
                        cin>>d1;
                        cin.rdbuf(stream_buffer_cin); // in order to load from cin
                    }
                    else
                        cin>>d1;
                }
                catch(exception &m){
                    cout<<endl;
                    cout<<m.what()<<endl;
                    return 0;
                }
                if(save)
                {
                cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                cout<<endl;
                d1.GetDNAStrandsEncodingMe(r2);
                cout.rdbuf(stream_buffer_cout); // in order to load from cin
                }
                else{
                    cout<<endl;
                    d1.GetDNAStrandsEncodingMe(r2);
                }
            }
            else if(y==2)
            {
                Protein d2;
                try
                {
                    if(load)
                    {
                        cin.rdbuf(stream_buffer_file);  // in oreder to load from file
                        cin>>d1;
                        cin.rdbuf(stream_buffer_cin); // in order to load from cin
                    }
                    else
                        cin>>d1;
                }
                catch(exception &l){
                    cout<<endl;
                    cout<<l.what()<<endl;
                    return 0;
                }
                cout<<endl;
                Protein d3;
                d3 = d1 + d2;
                if(save){
                cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                cout<<d3<<endl;
                cout.rdbuf(stream_buffer_cout); // in order to load from cin
                }
                else{
                    cout<<d3<<endl;
                }
            }
            else if(y==3)
            {
                Protein d4;
                try
                {
                    if(load)
                    {
                        cin.rdbuf(stream_buffer_file);  // in oreder to load from file
                        cin>>d1;
                        cin.rdbuf(stream_buffer_cin); // in order to load from cin
                    }
                    else
                        cin>>d1;
                }
                catch(exception &y){
                    cout<<endl;
                    cout<<y.what()<<endl;
                    return 0;
                }
                cout<<endl;
                if(d1 == d4){
                    if(save){
                    cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                    cout<<endl;
                    cout<<" Indetical Two Protein"<<endl;
                    cout.rdbuf(stream_buffer_cout); // in order to load from cin
                    }
                    else{
                        cout<<endl;
                        cout<<" Indetical Two Protein"<<endl;
                    }
                }
                else{
                    if(save){
                    cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                    cout<<" Not Equal!"<<endl;
                    cout.rdbuf(stream_buffer_cout); // in order to load from cin
                    }
                    else{
                        cout<<" Not Equal!"<<endl;
                    }
                }
            }
            else if(y==4){
                    if(save)
                    {
                        cout.rdbuf(stream_buffer_file2);  // in oreder to load from file
                        d1.Print();
                        cout.rdbuf(stream_buffer_cout); // in order to load from cin
                    }
                    else
                        d1.Print();
            }
        }
        else if(x == 0) /// To Stop Program
        {
            cont = false;
            return 0;

        }
        else{ /// TO Stop if Wrong input At Main Menu
            cout<<endl;
            cout<<" Wrong Input"<<endl;
            cout<<endl;
        }
    }
   ///---------=----------------=--------------------=----------------------

    return 0;
}
