#pragma once
#ifndef CODONSTABLE_H
#define CODONSTABLE_H
#include<string>
#include<iostream>
#include<cstdlib>
#include<fstream>
using namespace std;
struct Codon
{
	char value[4];    	    // 4th location for null character
	char AminoAcid;  	    // corresponding AminoAcid according to Table
};
// need to create one object of that class to load the AminoAcids table
// into memory
class CodonsTable
{
public:
	Codon codons[64]; /// array of 64 Object
	// constructors and destructor
	CodonsTable();/// constructor
	~CodonsTable();///Destructor
	// function to load all codons from the given text file
	void LoadCodonsFromFile(string);/// Load table Data from File
	Codon getAminoAcid(char *); ///Getter for AminoAcid
	void setCodon(char *, char, int);///Setter for Codon
	Codon getCodon(int);///Getter for Codon
};
#endif // CODONSTABLE_H
