#pragma once
//------------------------------------------
#ifndef SEQUENCE_H
#define SEQUENCE_H
//--------------------------------
#include<iostream>
#include <cstdlib>
#include<cstring>
#include<vector>
#include<algorithm>
using namespace std;
class InvalidChar :public exception{ ///Exceotion Class
public:
    virtual const char * what() const throw()
    {
        return "Invalid Sequence Character";
    }
};
class Sequence
{
//protected:
public:
	char * sequence; ///Sequence Carry characters
	int length; /// to determine Sequence Length
	// constructors and destructor
	Sequence(); /// default Constructor
	Sequence(int); /// Constructor for length
	Sequence(Sequence&); /// Copy Constructor
	virtual ~Sequence(); /// Virtual Destructor
	virtual void Print() = 0; /// Pure Virtual Abstracted Function
	void setSequence(char*); /// Setter
	char* getSequence(); /// Getter
	friend char* Align(Sequence *, Sequence &);/// Alignment (Longest Common Sequence).
};

#endif // SEQUENCE_H


