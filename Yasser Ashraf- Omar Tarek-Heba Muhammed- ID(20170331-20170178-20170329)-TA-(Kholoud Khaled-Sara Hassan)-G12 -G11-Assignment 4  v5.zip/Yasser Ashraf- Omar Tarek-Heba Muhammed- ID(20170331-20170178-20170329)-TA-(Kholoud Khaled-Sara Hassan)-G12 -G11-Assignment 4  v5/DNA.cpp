#include"DNA.h"
DNA::DNA()
{
	type = promoter;
	complementary_strand = NULL;
	startIndex = 0;
	endIndex = 0;
}
DNA::DNA(char * seq, DNA_Type atype,int l)
{
	this->length = l;
	this->sequence = new char[this->length];
	setSequence(seq);
	setType(atype);
}
DNA::DNA(DNA& rhs)
{
	this->length = rhs.length;
	this->sequence = new char[length];
	for (int i = 0; i < rhs.length; i++)
	{
		this->sequence[i] = rhs.sequence[i];
	}
}
DNA::~DNA()
{
}
void DNA::setType(DNA_Type s)
{
	type = s;
}
DNA_Type DNA::getType()
{
	return type;
}
void DNA::BuildComplementaryStrand(int startIndex, int endIndex)
{
	complementary_strand = new DNA;
	complementary_strand->length = length;
	if (startIndex == -1 && endIndex == -1) {
		startIndex = 0;
		endIndex = length;
		complementary_strand->sequence = new char[length]; /// Get Complement A->T, T->A , C->G, G->C;
		for (int i = startIndex; i < endIndex; i++) {
			if (sequence[i] == 'A') { complementary_strand->sequence[i] = 'T'; }
			else if (sequence[i] == 'T') { complementary_strand->sequence[i] = 'A'; }
			else if (sequence[i] == 'C') { complementary_strand->sequence[i] = 'G'; }
			else if (sequence[i] == 'G') { complementary_strand->sequence[i] = 'C'; }
		}
	}
	else {
		for (int i = startIndex; i < endIndex; i++) {
			if (sequence[i] == 'A') { complementary_strand->sequence[i] = 'T'; }
			else if (sequence[i] == 'T') { complementary_strand->sequence[i] = 'A'; }
			else if (sequence[i] == 'C') { complementary_strand->sequence[i] = 'G'; }
			else if (sequence[i] == 'G') { complementary_strand->sequence[i] = 'C'; }
		}
	}
	for (int i = 0; i < (length / 2); i++)
	{
		swap(complementary_strand->sequence[i], complementary_strand->sequence[length - i - 1]); ///Swap to by from 5' to 3
	}
}
RNA& DNA::ConvertToRNA()
{
	cout << "Choose Your Sequence For:	" << endl;
	cout << " 1-First Strand \n 2-Second Strand " << endl;
	int choice;
	cout << "Please Enter Your Choice:	";
	cin >> choice;
	if (choice == 1 || choice == 2){
		if (choice == 1) { /// first Strand
			char* rnaSeq = new char[this->length];
			for (int i = 0; i < this->length; i++)
			{
				if (this->sequence[i] == 'T')
				{
					rnaSeq[i] = 'U';
				}
				else {
					rnaSeq[i] = sequence[i];
				}
			}
			RNA *d = new RNA(rnaSeq, mRNA, this->length);
			return (*d);
		}
		else { /// Second Strand (Complement Strand)
			BuildComplementaryStrand(-1, -1);
			char* rnaSeq = new char[this->length];
			for (int i = 0; i < this->length; i++)
			{
				if (complementary_strand->sequence[i] == 'T') ///change each T to U
				{
					rnaSeq[i] = 'U';
				}
				else {
					rnaSeq[i] = complementary_strand->sequence[i];
				}
			}
			RNA * d = new RNA(rnaSeq, mRNA, this->length);
			return (*d);
		}
	}
	else{
        cout<<"Invalid Input"<<endl;
	}
}
void DNA::Print()
{
    cout<<"Your DNA Sequence is:    ";
    cout<<this->getSequence();
    cout<<endl;
    cout<<"Your DNA Type is:    ";
    if(this->getType() == 0){cout<<"Promoter"<<endl;}
	else if(this->getType() == 1){cout<<"Motif"<<endl;}
	else if(this->getType() == 2){cout<<"Tail"<<endl;}
	else if(this->getType() == 3){cout<<"Noncoding"<<endl;}
    cout<<endl;
    cout<<"Your DNA Sequence Length:    ";
    cout<<this->length;
    cout<<endl;

}
DNA& DNA::operator + (DNA q)
{
	char * temp;
	temp = new char[this->length];
	for (int i = 0; i < (this->length); i++)
	{
		temp[i] = sequence[i];
	}
	int w = this->length + q.length;
	sequence = new char[w];
	int k = 0;
	for (int i = 0; i < w; i++)
	{
		if (i < (w - q.length))
		{
			sequence[i] = temp[i];
		}
		else {
			sequence[i] = (q.sequence[k++]);
		}
	}
	this->length = w;
    return (*this);
}
bool DNA::operator ==(DNA q)
{
	bool status = false;
	if ((this->length) == q.length)
	{
		for (int i = 0; i < (q.length); i++)
		{
			if (sequence[i] == (q.sequence[i]))
			{
				status = true;
			}
			else
            {
                status = false;
				break;
            }

        }
	}
	else
    {
		status = false;
	}
	return status;
}
bool DNA::operator !=(DNA q)
{
	bool status = false;
	if ((this->length) != q.length)
	{
		for (int i = 0; i < (q.length); i++)
		{
			if (sequence[i] != (q.sequence[i]))
			{
				status = true;
			}
			else {
				status = false;
				break;
			}
		}

	}
	else {
		status = false;
	}
	return status;
}
istream & operator >> (istream& in, DNA & obj)
{
	cout << "Please Enter The Length Of Sequence:	";
	in >> obj.length;
	obj.sequence = new char[obj.length];
	int choice;
	cout<<"Enter Your choice:   ";
	cout<<endl;
	cout<<" 1-Promoter \n 2-Motif \n 3-Tail \n 4-noncoding"<<endl;
	cin>>choice;
	if(choice == 1)
    {
        obj.type = promoter;
    }
    else if(choice == 2)
    {
        obj.type = motif;
    }
    else if(choice == 3 )
    {
        obj.type = tail;
    }
    else if(choice == 4)
    {
        obj.type = noncoding;
    }
    else{
        cout<<"Wrong choice"<<endl;
        obj.type = promoter; ///NAMED Defualt Type
    }
    cout<<"Enter Your DNA Sequence: ";
    InvalidChar f;
	for (int i = 0; i < obj.length; i++)
	{
        in >> obj.sequence[i];
        if((obj.sequence[i] == 'A') ||(obj.sequence[i] =='G') ||( obj.sequence[i] == 'C' )||( obj.sequence[i] =='T')){ ///To check input Characters
            continue;
        }
        else
            throw f;
	}
	return in;
}
ostream& operator<<(ostream& out, DNA& obj)
{
    cout<<"Your DNA Sequence:   ";
	for (int i = 0; i < obj.length; i++)
	{
		out << obj.sequence[i] << "	";
	}
	cout<<endl;
	cout<<"Your DNA Type:   ";
	if(obj.type == 0){cout<<"Promoter"<<endl;}
	else if(obj.type == 1){cout<<"Motif"<<endl;}
	else if(obj.type == 2){cout<<"Tail"<<endl;}
	else if(obj.type == 3){cout<<"Noncoding"<<endl;}
	return out;
}
char* Align(DNA *obj, DNA&obj1)
{
    int m = obj->length;
    int n = obj1.length;
    int data[m][n];
    int lenCounter = 0;
    for(int i = 0 ; i < m; i++){
        for(int j = 0; j <n; j++)
        {
            data[i][j]=0;
        }
    }
    for(int i = 0 ; i < m; i++)
    {
        for(int j = 0 ; j < n ; j++)
        {
            data[i][j] = lenCounter;
            if( (i == 0||j >= 0))
                {data[i][j] = 0;}
        }
    }
    int index = 0;
    for(int i = 1; i < m; i++){
        for(int j = 1; j < n; j++){
            int index = max(data[i][j-1] , data[i-1][j]);
            if(obj->sequence[i] == obj1.sequence[j])
            {
                lenCounter+=1;
                data[i][j] = index + lenCounter;
            }
            else if(obj->sequence[i] != obj1.sequence[j]){
                int p = max(data[i][j-1] , data[i-1][j]);
                data[i][j] = p;
            }
        }
        lenCounter = 0;
    }
    int  length1=data[m-1][n-1];
    vector<char>lcs;
    int i=m-1;
    int j=n-1;
    while(i>0 && j>0)
    {
        if(data[i-1][j]==data[i][j-1]&&data[i][j]>data[i-1][j])
        {
            lcs.push_back(obj->sequence[i]);
            i--;
            j--;
        }
        else
        {
            if(data[i-1][j]>data[i][j-1])
            {
                i--;
            }
            else if(data[i][j-1]>data[i-1][j])
            {
                j--;
            }
        }
    }
    reverse(lcs.begin(),lcs.end());
    cout<<"LCS of  "<<obj->getSequence()<<"  and  "<<obj1.getSequence()<<"  is: ";
    for(int i=0;i < length1-1;i++)
    {
        cout<<lcs[i];
    }
}
///---------------------------------------------------------------------------------------------
