#pragma once
#ifndef DNA_H
#define DNA_H
#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include"Sequence.h"
#include"RNA.h"
using namespace std;
class RNA;
enum DNA_Type { promoter, motif, tail, noncoding };
class DNA : public Sequence
{
private:
	DNA_Type type; ///Type Of DNA SEQUENCE
	int startIndex; /// Start Index For Start Index
	int endIndex;  /// end index for Complement
	DNA * complementary_strand; ///DNA Pointer Carry Complement strand
public:
	// constructors and destructor
	DNA(); ///Constructor
	DNA(char *, DNA_Type,int sizee);
	DNA(DNA& rhs); ///Copy Constructor
	~DNA();///Destructor
	void setType(DNA_Type); ///Setter
	DNA_Type getType();///Getter
	RNA& ConvertToRNA(); ///Convert To Rna
	// function printing DNA sequence information to user
	void Print(); ///TO Print DATA
	// function to convert the DNA sequence to RNA sequence
	// It starts by building the complementary_strand of the current
	// DNA sequence (starting from the startIndex to the endIndex), then,
	// it builds the RNA corresponding to that complementary_strand.
	// function to build the second strand/pair of DNA sequence
	// To build a complementary_strand (starting from the startIndex to
	// the endIndex), convert each A to T, each T to A, each C to G, and
	// each G to C. Then reverse the resulting sequence.
	void BuildComplementaryStrand(int, int);//TODO swap && Exception;
	DNA& operator+(DNA);  ///Operator Plus
	bool operator==(DNA); /// Operator Check Equality
	bool operator!=(DNA); ///Operator !=
	friend istream & operator >>(istream&, DNA &obj); /// Cin Data
	friend ostream& operator <<(ostream& , DNA &obj); /// Cout Data

};
#endif // DNA_H

