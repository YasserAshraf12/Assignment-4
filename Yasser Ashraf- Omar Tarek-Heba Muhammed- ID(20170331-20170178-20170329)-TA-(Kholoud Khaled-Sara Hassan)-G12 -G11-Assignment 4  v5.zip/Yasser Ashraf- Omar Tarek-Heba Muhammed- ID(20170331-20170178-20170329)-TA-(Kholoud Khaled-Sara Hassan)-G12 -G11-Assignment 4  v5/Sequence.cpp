#include "Sequence.h"
Sequence::Sequence()
{
	sequence = NULL;
	length = 0;
}
Sequence::Sequence(int length)
{
	this->length = length;
	sequence = new char[length];
}
Sequence::Sequence(Sequence& rhs)
{
	sequence = new char[length];
	for (int i = 0; i < length; i++) {
		this->sequence[i] = rhs.sequence[i];
	}
}
Sequence::~Sequence()
{
	delete[] sequence; /// delete Sequence for no Memory Leak Or Storage Inflation
}
void Sequence::setSequence(char * c)
{
    int i = 0;
	for (int i = 0; i < length; i++)
	{
		sequence[i] = c[i];
	}
}
char* Sequence::getSequence()
{
    return sequence;
}
char* Align(Sequence * obj, Sequence &obj1)
{
    int m = obj->length;
    int n = obj1.length;
    int data[m][n];
    int lenCounter = 0;
    for(int i = 0 ; i < m; i++){
        for(int j = 0; j <n; j++)
        {
            data[i][j]=0; /// Initialize All Matrix with Zero Value
        }
    }
    for(int i = 0 ; i < m; i++)
    {
        for(int j = 0 ; j < n ; j++)
        {
            data[i][j] = lenCounter;
            if( (i == 0||j >= 0))
                {data[i][j] = 0;}
        }
    }
    int index = 0;
    for(int i = 1; i < m; i++){
        for(int j = 1; j < n; j++){
            int index = max(data[i][j-1] , data[i-1][j]);
            if(obj->sequence[i] == obj1.sequence[j])
            {
                lenCounter+=1;
                data[i][j] = index + lenCounter;
            }
            else if(obj->sequence[i] != obj1.sequence[j]){
                int p = max(data[i][j-1] , data[i-1][j]);
                data[i][j] = p;
            }
        }
        lenCounter = 0;
    }
    int  length1=data[m-1][n-1];
    vector<char>lcs;
    int i=m-1;
    int j=n-1;
    while(i>0 && j>0)
    {
        if(data[i-1][j]==data[i][j-1]&&data[i][j]>data[i-1][j])
        {
            lcs.push_back(obj->sequence[i]);
            i--;
            j--;
        }
        else
        {
            if(data[i-1][j]>data[i][j-1])
            {
                i--;
            }
            else if(data[i][j-1]>data[i-1][j])
            {
                j--;
            }
        }
    }
    reverse(lcs.begin(),lcs.end());
    cout<<"LCS of  "<<obj->getSequence()<<"  and  "<<obj1.getSequence()<<"  is: ";
    for(int i=0;i < length1-1;i++)
    {
        cout<<lcs[i];
    }
}
//-------------------------------------------------------------------------------
