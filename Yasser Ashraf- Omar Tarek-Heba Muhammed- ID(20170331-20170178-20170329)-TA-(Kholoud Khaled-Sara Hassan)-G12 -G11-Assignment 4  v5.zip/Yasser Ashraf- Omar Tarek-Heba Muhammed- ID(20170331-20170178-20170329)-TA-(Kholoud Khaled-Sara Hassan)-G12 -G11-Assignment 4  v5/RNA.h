#pragma once
#ifndef RNA_H
#define RNA_H
#include<iostream>
#include"Sequence.h"
#include"DNA.h"
#include"CodonsTable.h"
#include"Protein.h"
using namespace std;
class Protein;
class DNA;
enum RNA_Type { mRNA, pre_mRNA, mRNA_exon, mRNA_intron };
class RNA : public Sequence
{
private:
	RNA_Type type; ///RNA TYPE
public:
	// constructors and destructor
	RNA(); ///Constructor
	RNA(char * seq, RNA_Type atype, int sizee); ///Constructor
	RNA(RNA& rhs); ///Copy Constructor
	~RNA(); ///Destructor
	RNA_Type getType(); ///Getter for Type
	void setType(RNA_Type type); ///Setter for Type
	void Print(); ///Print Data
	DNA& ConvertToDNA(); /// Convert To DNA
	// function to be overridden to print all the RNA information
	// function to convert the RNA sequence into protein sequence
	// using the codonsTable object0
	///Convert To Protein
	Protein& ConvertToProtein(CodonsTable); //TODO STRUCT AT FINAL VERSION && CHECK IT
	// function to convert the RNA sequence back to DNA;
	///--------------------------------------------------
	RNA& operator+(RNA); ///Sum to Rna Sequence
	bool operator==(RNA);
	bool operator!=(RNA);
	friend istream& operator>>(istream& in , RNA & obj);
	friend ostream& operator<<(ostream& out , RNA & obj);
};
#endif // DNA_H
