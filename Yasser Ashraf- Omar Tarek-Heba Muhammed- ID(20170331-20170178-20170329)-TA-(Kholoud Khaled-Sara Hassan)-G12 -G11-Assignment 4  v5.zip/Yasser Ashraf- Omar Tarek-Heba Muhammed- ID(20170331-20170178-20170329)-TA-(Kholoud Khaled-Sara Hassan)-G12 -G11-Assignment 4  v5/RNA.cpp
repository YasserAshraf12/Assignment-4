#include"RNA.h"
RNA::RNA()
{
	type = mRNA; ///Default Type of RNA Sequence
}
RNA::RNA(char * seq, RNA_Type atype , int l) {
	this->length = l;
	this->sequence = new char[this->length];
	setSequence(seq);
	setType(atype);
}
void RNA::setType(RNA_Type atype)
{
	type = atype;
}
RNA_Type RNA::getType()
{
	return type;
}
RNA::RNA(RNA& rhs)
{
	this->length = rhs.length;
	this->sequence = new char[length];
	for (int i = 0; i < rhs.length; i++)
	{
		this->sequence[i] = rhs.sequence[i];
	}
}
RNA::~RNA()
{
}
void RNA::Print()
{
    cout<<"Your RNA Sequence is:    ";
    cout<<this->getSequence();
    cout<<endl;
    cout<<"Your RNA Type is:    ";
    if(this->getType()== 0){cout<<"mRna"<<endl;}
	else if(this->getType()== 1){cout<<"pre_mRNA"<<endl;}
	else if(this->getType()== 2){cout<<"mRNA_exon"<<endl;}
	else if(this->getType()== 3){cout<<"mRNA_intron"<<endl;}
    cout<<endl;
    cout<<"Your RNA Sequence Length:    ";
    cout<<this->length;
    cout<<endl;
}
Protein& RNA::ConvertToProtein(CodonsTable obj)
{
	Codon subCodon;
	char * temp= new char [length];
	char * protein = new char[length / 3];
	int k = 0; int j = 0;
	char* SubRna = new char[3];
	if (length % 3 == 0) {
		for (int i = 0; i < length; i++)
		{
			temp[i] = sequence[i];
		}
		while (k < length-2) {
			for (int u = 0; u < 3; u++) {
				SubRna[u] = temp[k];
				k++;
			}
			subCodon = obj.getAminoAcid(SubRna);
			if (subCodon.AminoAcid == ' '){
                break;
			}
			protein[j] = subCodon.AminoAcid;
			j++;
		}
		Protein* big = new Protein(protein,length/3);
		delete[]protein;
		delete[]SubRna;
		return *big;
	}
	else {
		cout << "Wrong Conversion" << endl;
	}
}
DNA& RNA::ConvertToDNA()
{
	char* dnaSeq = new char[(this->length)];
	for (int i = 0; i < (this->length); i++)
	{
		if (this->sequence[i] == 'U')
		{
			dnaSeq[i] = 'T';
		}
		else {
			dnaSeq[i] = sequence[i];
		}
	}
	DNA * sub = new DNA(dnaSeq, promoter, this->length);
 	return (*sub); /// Return Object
}
RNA& RNA::operator + (RNA q)
{
	char * temp;
	temp = new char[this->length];
	for (int i = 0; i < (this->length); i++)
	{
		temp[i] = sequence[i];
	}
	int w = this->length + q.length;
	sequence = new char[w];
	int k = 0;
	for (int i = 0; i < w; i++)
	{
		if (i < (w - q.length))
		{
			sequence[i] = temp[i];
		}
		else {
			sequence[i] = (q.sequence[k++]);
		}
	}
	this->length = w;
	return (*this);
}
bool RNA::operator ==(RNA q)
{
	bool status = false;
	if ((this->length) == q.length)
	{
		for (int i = 0; i < (q.length); i++)
		{
			if (sequence[i] == (q.sequence[i]))
			{
				status = true;
			}
			else {
				status = false;
				break;
			}
		}

	}
	else {
		status = false;
	}
	return status;
}
bool RNA::operator !=(RNA q)
{
	bool status = false;
	if ((this->length) != q.length)
	{
		for (int i = 0; i < (q.length); i++)
		{
			if (sequence[i] != (q.sequence[i]))
			{
				status = true;
			}
			else {
				status = false;
				break;
			}
		}

	}
	else {
		status = false;
	}
	return status;
}
istream & operator >> (istream & in, RNA & obj)
{
	cout << "Please Enter The Length Of Sequence:	";
	in >> obj.length;
	int choice;
	cout<<"Enter Your choice:   "<<endl;
	cout<<" 1-mRNA \n 2-pre_mRNA \n 3-mRNA_exon \n 4-mRNA_intron"<<endl;
	cin>>choice;
	if(choice == 1)
    {
        obj.type = mRNA;
    }
    else if(choice == 2)
    {
        obj.type = pre_mRNA;
    }
    else if(choice == 3 )
    {
        obj.type = mRNA_exon;
    }
    else if(choice == 4)
    {
        obj.type = mRNA_intron;
    }
    else{
        cout<<"Wrong choice"<<endl;
        obj.type = mRNA;
    }
    cout<<"Enter Your RNA Sequence:     ";
	obj.sequence = new char[obj.length];
	InvalidChar k;
	for (int i = 0; i < obj.length; i++)
	{
		in >> obj.sequence[i];
		if((obj.sequence[i] == 'A') ||(obj.sequence[i] =='G') ||( obj.sequence[i] == 'C' )||( obj.sequence[i] =='U')){
            continue;
        }
        else
            throw k;
	}
	return in;
}
ostream & operator<<(ostream & out, RNA& obj)
{
    cout<<"Your RNA Sequence:   ";
	for (int i = 0; i < obj.length; i++)
	{
		out << obj.sequence[i] << "	";
	}
	cout<<endl;
	cout<<"Your RNA Type:   ";
	if(obj.type== 0){cout<<"mRna"<<endl;}
	else if(obj.type == 1){cout<<"pre_mRNA"<<endl;}
	else if(obj.type == 2){cout<<"mRNA_exon"<<endl;}
	else if(obj.type == 3){cout<<"mRNA_intron"<<endl;}
	return out;
}
char* Align(RNA *obj, RNA&obj1)
{
    int m = obj->length;
    int n = obj1.length;
    int data[m][n];
    int lenCounter = 0;
    for(int i = 0 ; i < m; i++){
        for(int j = 0; j <n; j++)
        {
            data[i][j]=0;
        }
    }
    for(int i = 0 ; i < m; i++)
    {
        for(int j = 0 ; j < n ; j++)
        {
            data[i][j] = lenCounter;
            if( (i == 0||j >= 0))
                {data[i][j] = 0;}
        }
    }
    int index = 0;
    for(int i = 1; i < m; i++){
        for(int j = 1; j < n; j++){
            int index = max(data[i][j-1] , data[i-1][j]);
            if(obj->sequence[i] == obj1.sequence[j])
            {
                lenCounter+=1;
                data[i][j] = index + lenCounter;
            }
            else if(obj->sequence[i] != obj1.sequence[j]){
                int p = max(data[i][j-1] , data[i-1][j]);
                data[i][j] = p;
            }
        }
        lenCounter = 0;
    }
    int  length1=data[m-1][n-1];
    vector<char>lcs;
    int i=m-1;
    int j=n-1;
    while(i>0 && j>0)
    {
        if(data[i-1][j]==data[i][j-1]&&data[i][j]>data[i-1][j])
        {
            lcs.push_back(obj->sequence[i]);
            i--;
            j--;
        }
        else
        {
            if(data[i-1][j]>data[i][j-1])
            {
                i--;
            }
            else if(data[i][j-1]>data[i-1][j])
            {
                j--;
            }
        }
    }
    reverse(lcs.begin(),lcs.end());
    cout<<"LCS of  "<<obj->getSequence()<<"  and  "<<obj1.getSequence()<<"  is: ";
    for(int i=0;i < length1-1;i++)
    {
        cout<<lcs[i];
    }
}
///-------------------------------------------------------------------------------
