#include "Protein.h"
Protein::Protein()
{
	type = Cellular_Function;
}
Protein::Protein(char* p,int l)
{
	sequence = new char[l];
	this->length=l;
	for (int i = 0; i < l; i++)
	{
		sequence[i] = p[i];
	}
}
Protein::Protein(Protein& rhs)
{
	this->length = rhs.length;
	this->sequence = new char[length];
	for (int i = 0; i < rhs.length; i++)
	{
		this->sequence[i] = rhs.sequence[i];
	}
}
Protein::Protein(char * p, Protein_Type atype, int l)
{
	this->length = l;
	this->sequence = new char[this->length];
	setSequence(p);
	setType(atype);
}
void Protein::setType(Protein_Type atype){
    type = atype;
}
Protein_Type Protein::getType(){return type;}
DNA* Protein::GetDNAStrandsEncodingMe(DNA &bigDNA)
{
    DNA arr[50]; ///Array to Carry SubDNA from bigDna if it is correct
    int c =0;
    char * temp = new char[length *3]; /// Each protein Char Equal 3 char of either DNA or RNA
    int index = 0;
    RNA r1;
    Protein pl;
    CodonsTable table;
    for(int i = 0 ; i < ((bigDNA.length)); i++)
    {
        temp[index++] = bigDNA.sequence[i];
        if((index!=0)&&(index % (this->length * 3)== 0)){ //compare

            DNA d1(temp, promoter,6); ///Cutting DNA into Combinations of 3 and Get Protein
            r1 = d1.ConvertToRNA();
            pl = r1.ConvertToProtein(table);
            if(pl == (*this)){
                cout<<endl;
                cout<<"Equal"<<endl;
                cout<<endl;
                arr[c++]= d1;
                cout<<arr[c-1];
            }
            else{
                cout<<endl;
                cout<<" NOT Equal"<<endl;
                cout<<endl;
                i-=(length*3)-1;
            }
            index=0;
            if((i+length*3) > bigDNA.length){
                break;
            }
        }
    }
}
Protein::~Protein()
{
	delete[] sequence;
}
void Protein::Print()
{
    cout<<"Your Protein Sequence is:    ";
    cout<<this->getSequence();
    cout<<endl;
    cout<<"Your Protein Type is:    ";
    if(this->getType() == 0){cout<<"Hormon"<<endl;}
	else if(this->getType() == 1){cout<<"Enzyme"<<endl;}
	else if(this->getType() == 2){cout<<"TF"<<endl;}
	else if(this->getType() == 3){cout<<"Cellular_Function"<<endl;}
    cout<<endl;
    cout<<"Your Protein Sequence Length:    ";
    cout<<this->length;
    cout<<endl;
}
Protein& Protein::operator + (Protein q)
{
	char * temp;
    temp = new char[this->length];
	for (int i = 0; i < (this->length); i++)
	{
		temp[i] = sequence[i];
	}

	int w = this->length + q.length;
	sequence = new char[w];
	int k = 0;
	for (int i = 0; i < w; i++)
	{
            if (i < (w - q.length))
		{
			sequence[i] = temp[i];
		}
		else {
			sequence[i] = (q.sequence[k++]);
		}
	}
	this->length = w;
	return *(this);
}
bool Protein::operator ==(Protein q)
{
	bool status = false;
	if ((this->length) == q.length)
	{
		for (int i = 0; i < (q.length); i++)
		{
			if (sequence[i] == (q.sequence[i]))
			{
				status = true;
			}
			else {
				status = false;
				break;
			}
		}

	}
	else {
		status = false;
	}
	return status;
}
bool Protein::operator !=(Protein q)
{
	bool status = false;
	if ((this->length) != q.length)
	{
		for (int i = 0; i < (q.length); i++)
		{
			if (sequence[i] != (q.sequence[i]))
			{
				status = true;
			}
			else {
				status = false;
				break;
			}
		}

	}
	else {
		status = false;
	}
	return status;
}
istream & operator>>(istream & in, Protein & obj)
{
	cout << "Please Enter The Length Of Sequence:	";
	in >> obj.length;
	int choice;
	cout<<"Enter Your choice:   "<<endl;
	cout<<" 1-Hormon \n 2-Enzyme \n 3-TF \n 4-Cellular_Function"<<endl;
	cin>>choice;
	if(choice == 1)
    {
        obj.type = Hormon;
    }
    else if(choice == 2)
    {
        obj.type = Enzyme;
    }
    else if(choice == 3 )
    {
        obj.type = TF;
    }
    else if(choice == 4)
    {
        obj.type = Cellular_Function;
    }
    else{
        cout<<"Wrong choice"<<endl;
        obj.type = Cellular_Function;
    }
	obj.sequence = new char[obj.length];
	InvalidChar d;
	cout<<"Please Enter Your Protein Sequence:  ";
	for (int i = 0; i < obj.length; i++)
	{
		in >> obj.sequence[i];
		if((obj.sequence[i] == 'B') ||(obj.sequence[i] =='Z') ||( obj.sequence[i] == 'X' )||( obj.sequence[i] =='J') ||(obj.sequence[i] == 'U')){
            throw d;
        }
        else{
            continue;
        }
	}
	return in;
}
ostream & operator<<(ostream & out, Protein & obj)
{
    cout<<"Your protein Sequence:   ";
	for (int i = 0; i < obj.length; i++)
	{
		out << obj.sequence[i] << "	";
	}
	cout<<endl;
	cout<<"Your RNA Type:   ";
	if(obj.type == 0){cout<<"Hormon"<<endl;}
	else if(obj.type == 1){cout<<"Enzyme"<<endl;}
	else if(obj.type == 2){cout<<"TF"<<endl;}
	else if(obj.type == 3){cout<<"Cellular_Function"<<endl;}
	return out;
}
char* Align(Protein * obj, Protein &obj1)
{
    int m = obj->length;
    int n = obj1.length;
    int data[m][n];
    int lenCounter = 0;
    for(int i = 0 ; i < m; i++){
        for(int j = 0; j <n; j++)
        {
            data[i][j]=0;
        }
    }
    for(int i = 0 ; i < m; i++)
    {
        for(int j = 0 ; j < n ; j++)
        {
            data[i][j] = lenCounter;
            if( (i == 0||j >= 0))
                {data[i][j] = 0;}
        }
    }
    int index = 0;
    for(int i = 1; i < m; i++){
        for(int j = 1; j < n; j++){
            int index = max(data[i][j-1] , data[i-1][j]);
            if(obj->sequence[i] == obj1.sequence[j])
            {
                lenCounter+=1;
                data[i][j] = index + lenCounter;
            }
            else if(obj->sequence[i] != obj1.sequence[j]){
                int p = max(data[i][j-1] , data[i-1][j]);
                data[i][j] = p;
            }
        }
        lenCounter = 0;
    }
    int  length1=data[m-1][n-1];
    vector<char>lcs;
    int i=m-1;
    int j=n-1;
    while(i>0 && j>0)
    {
        if(data[i-1][j]==data[i][j-1]&&data[i][j]>data[i-1][j])
        {
            lcs.push_back(obj->sequence[i]);
            i--;
            j--;
        }
        else
        {
            if(data[i-1][j]>data[i][j-1])
            {
                i--;
            }
            else if(data[i][j-1]>data[i-1][j])
            {
                j--;
            }
        }
    }
    reverse(lcs.begin(),lcs.end());
    cout<<"LCS of  "<<obj->getSequence()<<"  and  "<<obj1.getSequence()<<"  is: ";
    for(int i=0;i < length1-1;i++)
    {
        cout<<lcs[i];
    }
}
