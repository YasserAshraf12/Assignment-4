#include "CodonsTable.h"
CodonsTable::CodonsTable()
{
	LoadCodonsFromFile("RNA_codon_table.txt");
}
CodonsTable::~CodonsTable()
{
}
void CodonsTable::LoadCodonsFromFile(string codonsFileName)
{
	fstream file;
	file.open(codonsFileName);
	if (!file) { cout << "Error Opening file"; }///Check File is Opened
	int  i = 0;
	while (!file.eof())///Check End of File
	{

		for (int j = 0; j < 3; j++) {
			file >> codons[i].value[j];///Read 3 Characters
		}
		file >> codons[i].AminoAcid;
		if (codons[i].AminoAcid == ' ')
			file >> codons[i].AminoAcid;
		i++;
	}
}
Codon CodonsTable::getAminoAcid(char * value)
{
	Codon main;///Temp Codon
	main.value[0] = value[0];
	main.value[1] = value[1];
	main.value[2] = value[2];
	for (int i = 0; i < 64; i++) {
		if ((main.value[0] == codons[i].value[0]) && (main.value[1] == codons[i].value[1]) && (main.value[2] == codons[i].value[2]))
		{
			main.AminoAcid = codons[i].AminoAcid;
			return main;
		}
	}
}
void CodonsTable::setCodon(char * value, char AminoAcid, int index)
{
	Codon main;
	main.value[0] = value[0];
	main.value[1] = value[1];
	main.value[2] = value[2];
	main.value[3] = value[3];
	main.AminoAcid = AminoAcid;
	codons[index] = main;
}
Codon CodonsTable::getCodon(int index)
{
	Codon main;
	main.value[0] = codons[index].value[0];
	main.value[1] = codons[index].value[1];
	main.value[2] = codons[index].value[2];
	main.AminoAcid = codons[index].AminoAcid;
	return main;
}
