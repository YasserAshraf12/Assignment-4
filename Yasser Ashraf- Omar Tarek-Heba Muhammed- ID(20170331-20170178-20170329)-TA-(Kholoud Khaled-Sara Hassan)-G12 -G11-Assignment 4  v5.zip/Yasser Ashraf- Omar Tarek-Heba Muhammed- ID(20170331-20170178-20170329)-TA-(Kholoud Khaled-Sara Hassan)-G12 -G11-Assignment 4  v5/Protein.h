#pragma once
#include<cstring>
#include<iostream>
#include<vector>
#include"Sequence.h"
#include"DNA.h"
#include"RNA.h"
#include"CodonsTable.h"
class DNA;
enum Protein_Type { Hormon, Enzyme, TF, Cellular_Function };
class Protein : public Sequence
{
private:
	Protein_Type type;
public:
	// constructors and destructor
	Protein(); ///Constructor
	Protein(char *,int); ///Constructor
	Protein(char *, Protein_Type , int sizee); /// Constructor
	Protein(Protein&); ///Copy Constructor
	~Protein(); /// Destructor
	// return an array of DNA sequences that can possibly
			// generate that protein sequence
	DNA* GetDNAStrandsEncodingMe(DNA &); ///Compare BIGDNA Protein With current Protein and Print Result if identical
	Protein_Type getType(); ///Getter
	void setType(Protein_Type); ///Setter
	Protein& operator + (Protein); ///Summation
	bool operator == (Protein);
	bool operator != (Protein);
	friend istream& operator >> (istream& in , Protein &);
	friend ostream& operator << (ostream& out, Protein &);
	void Print();
};
